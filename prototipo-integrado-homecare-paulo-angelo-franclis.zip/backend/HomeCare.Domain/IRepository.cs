﻿namespace HomeCare.Domain
{
    public interface IRepository<T> where T: IAggregateRoot
    {
    }
}
