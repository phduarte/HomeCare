﻿//namespace HomeCare.Domain.Payments
//{
//    public interface IPaymentNotificationFacade
//    {
//        void NotifyPaymentRefund(Payment payment);
//        void NotifyPaymentConfirmed(Payment payment);
//    }
//}
