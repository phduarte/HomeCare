﻿namespace HomeCare.Domain.Payments
{
    public enum PaymentStatus
    {
        Created = 0,
        Requested = 1,
        Confirmed = 2,
        Rejected = 3,
    }
}
