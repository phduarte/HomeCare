﻿//namespace HomeCare.Domain.Contracts
//{
//    public interface IContractFinishedNotificationFacade
//    {
//        void NotifyContractCancelled(Contract contract);
//        void NotifyContractFinished(Contract contract);
//        void NotifyServiceIsDone(Contract contract);
//        void NotifyContractEmitted(Contract contract);
//    }
//}
