﻿namespace HomeCare.Domain.Contracts
{
    public enum ContractStatus
    {
        Sketch = 0,
        Emitted = 1,
        Done = 2,
        Finished = 3,
        Canceled = 4
    }
}
