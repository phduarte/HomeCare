﻿namespace HomeCare.Domain.Clients
{
    public class Client : User, IAggregateRoot
    {
    }
}
