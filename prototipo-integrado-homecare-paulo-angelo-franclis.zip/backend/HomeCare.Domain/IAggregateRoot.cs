﻿namespace HomeCare.Domain
{
    public interface IAggregateRoot
    {
    }
}
