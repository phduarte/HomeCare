﻿namespace HomeCare.Domain.Suppliers
{
    public enum SearchType
    {
        None,
        Quality,
        Price
    }
}
