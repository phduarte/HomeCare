﻿namespace HomeCare.SendGrid
{
    public class SendGridOptions
    {
        public string ApiKey { get; set; }
    }
}
