﻿namespace HomeCare.Models
{
    public class PaymentResponse
    {

    }
}
