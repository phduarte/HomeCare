﻿namespace HomeCare.WebApi.Models
{
    public class PaymentConfirmRequest
    {
    }
}
