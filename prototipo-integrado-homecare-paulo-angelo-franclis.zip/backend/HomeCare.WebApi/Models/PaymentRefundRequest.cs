﻿namespace HomeCare.WebApi.Models
{
    public class PaymentRefundRequest
    {
        public Guid Id { get; set; }
    }
}
