using NUnit.Framework;

namespace HomeCare.Domain.Tests.Suppliers
{
    public class SupplierServiceTests
    {
        [Test]
        public void Test1()
        {
            Assert.True(true);
        }
    }
}