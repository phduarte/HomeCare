﻿namespace HomeCare.WebApi.Payments.Models; 

internal class PaymentRefundRequest
{
    public Guid Id { get; set; }
}
